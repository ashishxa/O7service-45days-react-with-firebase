// Create a function which prints a number multiplied by three, call this function 3 times with different number
function multiByThree(num){
    console.log(num*3)
}
multiByThree(10)
multiByThree(4)
multiByThree(5)

// Create an arrow function which takes two arguments and performs multiplication of these number

let multi=(a,b)=>{
    console.log(a*b)
}
multi(2,3)
// Create an arrow function which take username as argument, if no value is passed in argument then it must print hello player
let printName=(userName="Hello Player")=>{
    console.log(userName);
}
printName("Janki")
printName()
// Create an arrow function to print Date and Month 
let printDate=()=>{
    let date=new Date()
    // console.log("Date is ", date.getDate(), "Month is ", date.getMonth()+1)
    console.log(`Date is ${date.getDate()} Month is ${date.getMonth()+1}`)
}
printDate()
// Using interval create a timer which shows seconds and milli-seconds
// setInterval(()=>{
//     let date=new Date()
//     console.log(`${date.getSeconds()} : ${date.getMilliseconds()}`);
    
// },100)
// Create a countdown timer starting from 1 and goes like 1,2,3..  using setInterval, displaying each second.
let count=1
// setInterval(()=>{
//     console.log(count);
//     count++;
//     //count=count+1
// },1000)
//1
//  log "Boom!" after a 3-second delay once.
// setTimeout(()=>{
//     console.log("Boom!!"); 
// },3000)
// Create a function that simulates rolling a six-sided die and returns a random number between 1 and 6.

function getNum(){
    let n=Math.round(Math.random()*6+1)
    console.log(n);
}
getNum()
// Build a simple digital clock that updates the current hour, minute, and second every second.
setInterval(()=>{
    let date=new Date()
    console.log(`${date.getHours()}:${date.getMinutes()}:${date.getSeconds()}`);
},1000)
