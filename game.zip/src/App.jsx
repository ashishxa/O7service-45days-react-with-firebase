import Counter from "./components/pages/Counter";

export default function App(){
  return(
    <>
    <Counter/> 
  
    </>
  )
}