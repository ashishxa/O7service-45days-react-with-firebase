import React, { useState } from "react";
import './Counter.css'; 
export default function Counter(){
   
        
  const [player1Score, setPlayer1Score] = useState(0);
  const [player2Score, setPlayer2Score] = useState(0);
  const [turn, setTurn] = useState(0); // 0 = none, 1 = P1, 2 = P2
  const [winner, setWinner] = useState("");
  const [isPlaying, setIsPlaying] = useState(false);

  const startGame = () => {
    setIsPlaying(true);
    setWinner("");
    setPlayer1Score(0);
    setPlayer2Score(0);
    setTurn(1);
  };

  const hit = () => {
    if (!isPlaying || winner) return;

    const randomNum = Math.floor(Math.random() * 90) + 10; // 10–99

    if (turn === 1) {
      setPlayer1Score(randomNum);
      setTurn(2);
    } else if (turn === 2) {
      setPlayer2Score(randomNum);
      setTurn(0);
    }
  };

  const findWinner = () => {
    if (!isPlaying) return;

    let result = "";

    if (player1Score > player2Score) {
      result = "Player 1 Wins!";
    } else if (player2Score > player1Score) {
      result = "Player 2 Wins!";
    } else {
      result = "It’s a Tie!";
    }

    setWinner(result);
    setIsPlaying(false);

    // Show prompt
    window.prompt("Result:", result);
  };

  const restartGame = () => {
    setIsPlaying(false);
    setPlayer1Score(0);
    setPlayer2Score(0);
    setTurn(0);
    setWinner("");
  };

  
   return(
       <div className="game-container">
      <button className="start-btn" onClick={startGame}>Start</button>
      {isPlaying && <div className="status">Game is Running..</div>}
      {turn > 0 && <div className="turn">Turn {turn}</div>}

      <div className="scores">
        <div className="player">
          <h2>Score Player 1: <span>{player1Score}</span></h2>
        </div>
        <div className="player">
          <h2>Score Player 2: <span>{player2Score}</span></h2>
        </div>
      </div>

      <div className="buttons">
        <button
          onClick={hit}
          disabled={!isPlaying || winner || turn === 0}
          className="hit-btn"
        >
          Hit
        </button>
        <button
          onClick={findWinner}
          disabled={turn !== 0 || winner || !isPlaying}
          className="winner-btn"
        >
          Winner
        </button>
        <button onClick={restartGame} className="restart-btn">
          Restart
        </button>
      </div>

      {/* Optional: still show winner text below */}
      <div className="winner">{winner}</div>
    </div>
    )
}