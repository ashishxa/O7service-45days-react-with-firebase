//1 answer
let n = 5; 

for (let i = 0; i < n; i++) {
  let stars = '*'.repeat(2 * i + 1);
  console.log(stars);
}

//2 answer
function printEvenNumbers(arr) {
  for (let i = 0; i < arr.length; i++) {
    if (arr[i] % 2 === 0) {
      console.log(arr[i]);
    }
  }
}

//3 answer
function calculateDiscount(price) {
  let discount = 0;

  if (price > 1000) {
    discount = price * 0.10;
  } else if (price >= 500 && price <= 1000) {
    discount = price * 0.05;
  }

  let finalPrice = price - discount;

  console.log("Original Price: $" + price);
  console.log("Discount: $" + discount);
  console.log("Final Price: $" + finalPrice);
}

//4 answer
function calculateBMI(weight, height) {
  let bmi = weight / (height * height); 
  console.log("BMI: " + bmi.toFixed(2));

  if (bmi < 18.5) {
    console.log("Category: Underweight");
  } else if (bmi >= 18.5 && bmi < 24.9) {
    console.log("Category: Normal weight");
  } else if (bmi >= 25 && bmi < 29.9) {
    console.log("Category: Overweight");
  } else {
    console.log("Category: Obesity");
  }
}

//5 answer
function checkTriangleType(a, b, c) {
  // Check for a valid triangle
  if (a + b <= c || a + c <= b || b + c <= a) {
    console.log("Not a valid triangle");
    return;
  }

  // Check for right angle triangle
  if (
    a * a === b * b + c * c ||
    b * b === a * a + c * c ||
    c * c === a * a + b * b
  ) {
    console.log("Right angle triangle");
  } 
  // Check for equilateral
  else if (a === b && b === c) {
    console.log("Equilateral triangle");
  } 
  // Check for isosceles
  else if (a === b || b === c || a === c) {
    console.log("Isosceles triangle");
  } 
  // Otherwise, it's scalene
  else {
    console.log("Scalene triangle");
  }
}

//6 answer
function countVowels(str) {
  let count = 0;
  let vowels = 'aeiouAEIOU';

  for (let i = 0; i < str.length; i++) {
    if (vowels.includes(str[i])) {
      count++;
    }
  }

  console.log("Number of vowels:", count);
}

//7answer
let x = [1, 4, 2, 42, 4, 6, 2, 56, 4, 56];

for (let i = 0; i < x.length; i += 2) {
  console.log(x[i]);
}

//8answer
let arr = ["Janki", 12, 23, 33.33, "Singh", true];

for (let i = 0; i < arr.length; i++) {
  if (typeof arr[i] === "string") {
    console.log(arr[i]);
  }
}

//9answer


let arr = [1, 10, 100, 3, 6, 8];

// Add one element at the start
arr.unshift(0);

// Add one element at the end
arr.push(200);

// Traverse using for loop
console.log("Using for loop:");
for (let i = 0; i < arr.length; i++) {
  {
    console.log(arr[i]);
  }
}

// Traverse using for...in loop
console.log("Using for...in loop:");
for (let index in arr) {
  {
    console.log(arr[index]);
  }
}

// Print the length of the array
{
  console.log("Length of array:", arr.length);
}



//10 answer

let fruits = [];

// 1. Add "Apple" and "Banana" to the end of the array
fruits.push("Apple", "Banana");

// 2. Add "Orange" to the end of the array
fruits.push("Orange");

// 3. Remove the first element from the array
fruits.shift();

// 4. Add "Grapes" to the start of the array
fruits.unshift("Grapes");

// 5. Remove the last element from the array
fruits.pop();

// 6. Add "Pears" between Apple and Banana
// Find index of Banana and insert Pears before it
let bananaIndex = fruits.indexOf("Banana");
if (bananaIndex !== -1) {
  fruits.splice(bananaIndex, 0, "Pears");
}

// 7. Check if "litchi" is included
if (fruits.includes("litchi")) {
  console.log("exist");
}

// 8. Traverse and print each fruit with index (starting from 1)
for (let i = 0; i < fruits.length; i++) {
  console.log((i + 1) + ". " + fruits[i]);
}

// Final array (optional)
console.log("Final array:", fruits);

