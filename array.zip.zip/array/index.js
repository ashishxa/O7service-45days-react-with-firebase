// 1 .create an array named friends with five of your friends name
let friends=["Rishi","Rohan","jassa","harjot","Harsh"];

//print the array and its length
console.log("freinds Array:",friends);
console.log("length of friends array:",friends.length);

//print friend at position 3
console.log("friend at position 3:",friends[2]);

//add a new friends name BillGates at first position
friends.unshift("BillGates")
console.log("After unshift",friends)

//Delete friend from last position
friends.pop()
console.log("array after pop",friends)

//Traverse each friend name
for(let y in friends){
    // console.log(y); //index
    console.log(friends[y])
}

// 2. create an object named employee with keys employee name,department and salary
let employee={
    employee_name: "Sagar",
    department:"engineering",
    salary:1005000
}
//print the object and its type
console.log("Employee object:",employee);
console.log("Type of Employee object:",typeof employee);

//Delete department
delete employee.department
console.log("after deleting department:",employee);

//add a new key named join year
employee.joinyear=2025
console.log(employee);

//replace the employee_name with Ravinder
employee.employee_name="ronaldo";
console.log(employee);

//Create a function that takes an array of numbers and returns their average
function average(arr){
    let count=arr.length
    let total=0
    for(let i in arr){
        total+=arr[i]
        //console.log(arr[i]*2)
    }
    let av=total/count
    console.log(av);
}
average([1,2,3,4,5])

//create an object called book with title ,author and pages.write a function that adda a new property genre to it.
let book = {
    title: "Bullhe shah",
    author: "taufiq Rafat",
    pages: 352
};
function addGenre(bookObject,genre){
    bookObject.genre=genre
}
addGenre(book,"fiction")
console.log(book);

// create an array of integers and write n function that doubles each element and prints the result.
let integers=[22,55,88,99,14];
function doubleElements(arr){
    return arr.map(function(element){
        return element*2;
    });
}
let  doubleArray=doubleElements(integers);
console.log(doubleArray);

//wrie a function that accepts an object with key name and city and returns a greeting message using those values.
function greetUser(obj){
    console.log("hello",obj.name,"welcome to", obj.city);
}
greetUser({name:"Ravinder",city:"Jalandhar"})